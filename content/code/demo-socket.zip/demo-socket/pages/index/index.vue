<template>
	<view class="content">
		<view v-for="msg in msgFromServer">
			{{msg}}
		</view>
		<view class="text-area">
			<input type='text' v-model="currentMsg" placeholder="请输入文字"> </input>
		</view>
		<view>
			<button @click="sendMsg()">发送</button>
			<button @click="initSocket()">连接</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello',
				currentMsg: "",
				msgFromServer: [],
			}
		},
		onLoad() {			
			uni.onSocketMessage(res => {
			  console.log('收到服务器内容：' + res.data);
			  this.msgFromServer.push(res.data)
			});
		},
		methods: {
			sendMsg: function() {
				uni.sendSocketMessage({
					data: this.currentMsg
				})
				this.currentMsg = ""
			},
			initSocket: function() {
				uni.connectSocket({
				    url: 'ws://icewould.tpddns.cn:18123',
				    success: data => {
				        console.log(data)
				    }
				})
			}
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
