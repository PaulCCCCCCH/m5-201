<template>
	<view>
		<view class="gameboard">
			<view v-for="row in height_array">
				<div class="line">
					<view v-for="col in width_array" class="block-holder" v-bind:class="{active: isCovered(initPiece, row, col)}">
						
					</view> 
				</div>
			</view>
		</view>
		<button @click="increment()">点我下落</button>
		<button @click="moveLeft()">点我向左</button>
	</view>
</template>

<script>
	import {uniBadge} from '@dcloudio/uni-ui'
	
	

	export default {
		components: {
			uniBadge
		},
		data() {
			return {
				BOARD_HEIGHT: 20,
				BOARD_WIDTH: 10,
				height_array: null,
				width_array: null,
				initPiece: {
					layout: [[0, 1], [0, 0], [1, 0], [2, 0]],
					color: 'red',
					row: 5,
					col: 5
				}
			}
		},
		methods: {
			isCovered: function(piece, row, col) {

				for (let i = 0; i < piece.layout.length; i++) {
					if (piece.layout[i][0] + piece.row == row && piece.layout[i][1] + piece.col == col) {
						return true
					}
				}
				return false
			},
			increment: function() {
				this.initPiece.row += 1;
			},
			moveLeft: function() {
				this.initPiece.col -= 1;
			}
		},
		onLoad() {
			this.height_array = new Array(this.BOARD_HEIGHT)
			for (let i = 0; i < this.BOARD_HEIGHT; i++) {
				this.height_array[i] = i
			}
			this.width_array = new Array(this.BOARD_WIDTH)
			for (let i = 0; i < this.BOARD_WIDTH; i++) {
				this.width_array[i] = i
			}
			window.setInterval(() => {
				console.log("selhtsake")
				this.initPiece.row += 1
			}, 1000)

		}

	}
</script>

<style>
.block-holder {
	display: inline-block;
	border: #000000 2px solid;
	width: 20px;
	height: 20px;
}
.line {
	line-height: 0px;
	width: 250px;
}
.gameboard {
	align-items: center;
	justify-content: center;
}
.active {
	background-color: red;
}

</style>
