<template>
	<view>
		<view v-if="finished">
			{{name}}
			{{price}}
			{{store}}
			{{storeOwner}}
		</view>
		<view v-else>
			
			
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				name: "正在加载",
				price: null,
				store: null,
				storeOwner: null,
				finished: false,
			}
		},
		methods: {
			
		},
		onLoad() {
			uni.request({
			    url: 'http://icewould.com:5201/getProduct?id=5',
			    success: (res) => {
					if (res.statusCode == 500) {
						// ....
					} else {
						this.name = res.data.name
						this.price = res.data.priece
						this.store = res.data.store
						this.storeOwner = res.data.storeOwner
						this.finished = true
					}
			    },
				fail: (res) => {
					this.name = "服务器错误"
				}
			});
		}
	}
</script>

<style>

</style>
